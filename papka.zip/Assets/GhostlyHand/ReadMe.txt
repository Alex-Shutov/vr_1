Hello fellow game developer!
You're free to use this shader in any commercial or personal project.
You can also edit the shader to whatever you need. 
Amplify Shader Editor was used in the creation of this shader

Shader supports forward rendering. Using deferred rendering with this shader might result incorrect visuals

Import the correct package based on your renderer:
--->BUILT-IN: If you're using Built-In Render Pipeline, open the package in Built-In Render Pipeline folder
--->URP: If you're using Universal Render Pipeline (URP), open the URP package in URP folder


FOR URP SETUP:
After unpacking the package, you need to enable Opaque Texture from the pipeline settings
Otherwise the material won't be completely transparent


I would appreciate if you credit me: wolderado
Check out my twitter for my other works:
@wolderado





Thanks for downloading this asset. I hope it helps!