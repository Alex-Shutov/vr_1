# Controller Sample

Demonstrates retrieving input from an XR controller with OpenXR using the Unity [Input System](https://docs.unity3d.com/Packages/com.unity.inputsystem@latest/).  
