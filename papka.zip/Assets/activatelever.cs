using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class activatelever : MonoBehaviour
{
	[SerializeField] private GameObject Lift;

	
	void OnCollisionEnter(Collision collision)
    {
		Lift.GetComponent<Rigidbody>().AddForce(100, 100, 100);
    }
}
